#!/bin/bash

echo $(ls | grep .sh | wc -l)
